var mWebGL = null;
var jmodel = X;//get mode from json file
var model = null;
var camera = null;
var qube = null;
var mouseDown = false;
var mx=null, my=null;

function main() {
	/* Init WebGL progarm */
	mWebGL = new MYASO.WebGL();
	mWebGL.initVertexShader(document.getElementById("vertexShader").innerHTML);
	mWebGL.initFragmentShader(document.getElementById("fragmentShader").innerHTML);		
	mWebGL.initShaderProgram();
	
	/* Create 3D model from json file */
	model = new MYASO.Group();
	for(var i=0;i<jmodel.qubes.length;i++){
		var q = jmodel.qubes[i];
		qube = new MYASO.Model(q.id,q.shape);
		qube.setTranslate((q.pos_x/256)+(q.size_x/512),(q.pos_y/256)+(q.size_y/512),(q.pos_z/256)+(q.size_z/512));
		qube.setScale(q.size_x/512,q.size_y/512,q.size_z/512);
		qube.setColor(q.colour);
		model.addModel(qube);
	}
	model.setTranslate(0.0,0.0,-5.0);
	model.setRotate(90,0,0);
	
	/* Create Camera */
	camera = new MYASO.Camera(75,1,100);
	mWebGL.addCamera(camera);
	mWebGL.initMatrix("umTransform");
	
	/* Buffers for WebGL */
	mWebGL.initBuffer("squareVertexPosition",qube.vsize,qube.vnum,qube.v);
	mWebGL.addGroup(model);
	
	/* Push WebGL to engine */
	MYASO.Engine.addRenders(mWebGL);
	
	/* Mouse events */
	document.getElementById("body").addEventListener("mousedown", function () {
    	mouseDown = true;
	});
	document.getElementById("body").addEventListener("mouseup",function () {
   	mouseDown = false;
	});
	document.getElementById("body").addEventListener("mousemove", function (e) {
		if(mx==null){
			mx = e.clientX;    	
		}
		if(my==null){
			my = e.clientY;
		}
    	if(mouseDown){
    		var x=mx-e.clientX,y=my-e.clientY;
    		
    		model.setRotate(model.xRotation-y,model.yRotation,model.zRotation+x);
    	}
    	mx = e.clientX;
    	my = e.clientY;
	});
}

main();